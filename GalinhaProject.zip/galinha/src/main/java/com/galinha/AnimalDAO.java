package com.galinha;

import java.util.ArrayList;
import java.util.List;

public class AnimalDAO implements DAO<Animal> {
  private ArrayList<Animal> animals = new ArrayList<Animal>();

    public AnimalDAO() {}
  
  
  
  public void add(Animal animal) {
      animals.add(animal);
  }   
  
  public Animal get(int indice) {
      if (indice >=0 && indice< animals.size()) {
          return animals.get(indice);
      }
      return null;
  }
  
  public void delete(Animal animal) {
      int indice = animals.indexOf(animal);
      if (indice != -1) {
          animals.remove(indice);
      }
  }
  
  public void update(Animal animal) {
      int indice = animals.indexOf(animal);
      if (indice != -1) {
          animals.set(indice, animal);
      }
  }
  
  public int size() {
      return animals.size();
  }

  @Override
  public List<Animal> getAll() {
      return animals;
  }
  
  
}
