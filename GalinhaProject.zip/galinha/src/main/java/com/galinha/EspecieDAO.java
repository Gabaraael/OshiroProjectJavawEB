package com.galinha;

import java.util.ArrayList;
import java.util.List;

public class EspecieDAO implements DAO<Especie> {
    private ArrayList<Especie> especies = new
            ArrayList<Especie>();

    public EspecieDAO() {}
    
    @Override
    public void add(Especie especie) {
      especies.add(especie);
    }

    @Override
    public Especie get(int indice) {
        if ((especies.size()>indice) && (indice>-1)){
            return especies.get(indice);
        }
        return null;
    }

    @Override
    public List<Especie> getAll() {
        return especies;
    }

    @Override
    public void delete(Especie especie) {
      int indice = especies.indexOf(especie);
      if (indice != -1) {
          especies.remove(indice);
      }
    }

    @Override
    public void update(Especie especie) {
      int indice = especies.indexOf(especie);
      if (indice != -1) {
          especies.set(indice, especie);
      }
    }

    @Override
    public int size() {
        return especies.size();
    }
    
}
