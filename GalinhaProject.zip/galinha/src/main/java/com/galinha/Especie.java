package com.galinha;

public class Especie {
    private int codigo;
    private String especie;
    private static int nextCodigo = 1;

    public Especie(String especie) {
        this.especie = especie;
        codigo = nextCodigo;
        nextCodigo++;
    }

    public Especie(int codigo, String especie) {
        this.codigo = codigo;
        this.especie = especie;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Especie other = (Especie) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return codigo+"-"+ especie;
    }
    
    
}
