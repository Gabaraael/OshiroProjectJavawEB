package com.galinha;


public class Animal {
  private static int nextCodigo = 1;
  private int codigo;
  private String descricao;
  private Especie especie;
  private double valor_unitario;
  private int estoque;

  public Especie getCategoria() {
    return especie;
  }

    public Animal(String descricao, Especie especie, double valor_unitario, int estoque) {
        this.codigo = nextCodigo;
        nextCodigo++;
        this.descricao = descricao;
        this.especie = especie;
        this.valor_unitario = valor_unitario;
        this.estoque = estoque;
    }

    public Animal(int codigo, String descricao, Especie especie, double valor_unitario, int estoque) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.especie = especie;
        this.valor_unitario = valor_unitario;
        this.estoque = estoque;
    }

    
    
    public int getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getValor_unitario() {
        return valor_unitario;
    }

    public int getEstoque() {
        return estoque;
    }
    
    public double getValor_total() {
        return valor_unitario * estoque;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return true;
    }
    
    
}
